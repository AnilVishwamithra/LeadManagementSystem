import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Lead } from './lead';

@Injectable({
  providedIn: 'root'
})
export class LeadService {

  private baseURL = "http://localhost:8080/api/v1/leads";

  constructor(private httpClient: HttpClient) { }
  
  getLeadsList(): Observable<Lead[]>{
    type NewType = Lead;

    return this.httpClient.get<NewType[]>(`${this.baseURL}`);
  }

  createLead(lead: Lead): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, lead);
  }

  getLeadById(id: number): Observable<Lead>{
    return this.httpClient.get<Lead>(`${this.baseURL}/${id}`);
  }

  updateLead(id: number, employee: Lead): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, lead);
  }

  deleteLead(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
