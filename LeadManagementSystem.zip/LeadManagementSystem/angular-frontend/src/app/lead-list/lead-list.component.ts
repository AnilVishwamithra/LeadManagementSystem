import { Component, OnInit } from '@angular/core';
import { Lead } from '../lead'
import { LeadService } from '../lead.service'
import { Router } from '@angular/router';
@Component({
  selector: 'app-lead-list',
  templateUrl: './lead-list.component.html',
  styleUrls: ['./lead-list.component.css']
})
export class LeadListComponent implements OnInit {

  employees: Lead[];

  constructor(private leadService: LeadService,
    private router: Router) { }

  ngOnInit(): void {
    this.getLeads();
  }

  private getLeads(){
    this.leadService.getLeadList().subscribe(data => {
      this.leads = data;
    });
  }

  leadDetails(id: number){
    this.router.navigate(['lead-details', id]);
  }

  updateLead(id: number){
    this.router.navigate(['update-lead', id]);
  }

  deleteLead(id: number){
    this.leadService.deleteLead(id).subscribe( data => {
      console.log(data);
      this.getLeads();
    })
  }
}
