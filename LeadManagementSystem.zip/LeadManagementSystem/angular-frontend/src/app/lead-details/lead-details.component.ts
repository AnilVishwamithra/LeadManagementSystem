import { Component, OnInit } from '@angular/core';
import { Lead } from '../lead';
import { ActivatedRoute } from '@angular/router';
import { LeadService } from '../lead.service';

@Component({
  selector: 'app-lead-details',
  templateUrl: './lead-details.component.html',
  styleUrls: ['./lead-details.component.css']
})
export class LeadDetailsComponent implements OnInit {

  id: number
  employee: Lead
  constructor(private route: ActivatedRoute, private leadService: LeadService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.lead = new Lead();
    this.leadService.getLeadById(this.id).subscribe( data => {
      this.lead = data;
    });
  }

}
