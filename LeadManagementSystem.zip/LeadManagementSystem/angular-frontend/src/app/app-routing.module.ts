import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LeadListComponent } from './lead-list/lead-list.component';
import { CreateLeadComponent } from './create-lead/create-lead.component';
import { UpdateLeadComponent } from './update-lead/update-lead.component';
import { LeadDetailsComponent } from './lead-details/lead-details.component';

const routes: Routes = [
  {path: 'leads', component: LeadListComponent},
  {path: 'create-lead', component: CreateLeadComponent},
  {path: '', redirectTo: 'leads', pathMatch: 'full'},
  {path: 'update-employee/:id', component: UpdateLeadComponent},
  {path: 'employee-details/:id', component: LeadDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],                                                                                                                                                                                                                                                                                                          
  exports: [RouterModule]
})
export class AppRoutingModule { }
