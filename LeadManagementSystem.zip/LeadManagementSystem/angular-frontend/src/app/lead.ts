export class Lead {
    id: number;
    firstName: string;
    lastName: string;
    emailId: string;
    mobileNumber: bigint;
}
