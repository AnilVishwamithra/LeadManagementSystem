import { Component, OnInit } from '@angular/core';
import { LeadService } from '../lead.service';
import { Lead } from '../lead';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-lead',
  templateUrl: './update-lead.component.html',
  styleUrls: ['./update-lead.component.css']
})
export class UpdateLeadComponent implements OnInit {

  id: number;
  lead: Lead = new Lead();
  constructor(private leadService: LeadService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.leadService.getLeadById(this.id).subscribe(data => {
      this.lead = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.leadService.updateLead(this.id, this.lead).subscribe( data =>{
      this.goToLeadList();
    }
    , error => console.log(error));
  }

  goToLeadList(){
    this.router.navigate(['/leads']);
  }
}
