import { Component, OnInit } from '@angular/core';
import { Lead } from '../lead';
import { LeadService } from '../lead.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-lead',
  templateUrl: './create-lead.component.html',
  styleUrls: ['./create-lead.component.css']
})
export class CreateLeadComponent implements OnInit {

  employee: Lead = new Lead();
  constructor(private leadService: LeadService,
    private router: Router) { }

  ngOnInit(): void {
  }

  saveLead(){
    this.leadService.createEmployee(this.lead).subscribe( data =>{
      console.log(data);
      this.goToLeadList();
    },
    error => console.log(error));
  }

  goToLeadList(){
    this.router.navigate(['/leads']);
  }
  
  onSubmit(){
    console.log(this.lead);
    this.saveLead();
  }
}
