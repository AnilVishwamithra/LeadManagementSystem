import { Lead } from './lead';

describe('Lead', () => {
  it('should create an instance', () => {
    expect(new Lead()).toBeTruthy();
  });
});
