import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LeadListComponent } from './lead-list/lead-list.component';
import { CreateLeadComponent } from './create-lead/create-lead.component';
import { FormsModule} from '@angular/forms';
import { UpdateLeadComponent } from './update-lead/update-lead.component';
import { LeadDetailsComponent } from './lead-details/lead-details.component'

@NgModule({
  declarations: [
    AppComponent,
    LeadListComponent,
    CreateLeadComponent,
    UpdateLeadComponent,
    LeadDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
