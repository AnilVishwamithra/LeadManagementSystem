package net.leads.springboot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.leads.springboot.exception.ResourceNotFoundException;
import net.leads.springboot.model.Lead;
import net.leads.springboot.repository.LeadRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class LeadController {

	@Autowired
	private LeadRepository leadRepository;
	
	// get all employees
	@GetMapping("/employees")
	public List<Lead> getAllLeads(){
		return leadRepository.findAll();
	}		
	
	// create lead rest api
	@PostMapping("/leads")
	public Lead createLead(@RequestBody Lead lead) {
		return leadRepository.save(lead);
	}
	
	// get lead by id rest api
	@GetMapping("/leads/{id}")
	public ResponseEntity<Lead> getLeadById(@PathVariable Long id) {
		Lead lead = leadRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Lead not exist with id :" + id));
		return ResponseEntity.ok(lead);
	}
	
	// update lead rest api
	
	@PutMapping("/leads/{id}")
	public ResponseEntity<Lead> updateLead(@PathVariable Long id, @RequestBody Lead leadDetails){
		Lead lead = leadRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Lead not exist with id :" + id));
		
		lead.setFirstName(leadDetails.getFirstName());
		lead.setLastName(leadDetails.getLastName());
		lead.setEmailId(leadDetails.getEmailId());
		
		Lead updatedLead = leadRepository.save(lead);
		return ResponseEntity.ok(updatedLead);
	}
	
	// delete lead rest api
	@DeleteMapping("/leads/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteLead(@PathVariable Long id){
		Lead lead = leadRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Lead not exist with id :" + id));
		
		leadRepository.delete(lead);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	
}
